﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Kinect;
using System.IO;
namespace HelloKinectMatrix
{
    class Program
    {


        static Skeleton[] skeletons;
        static void Main(string[] args)
        {
            if (KinectSensor.KinectSensors.Count > 0)
            {
                //设置控制台前景色
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Welcome to the Kinect Matrix...");

                //默认选择第一个Kinect传感器
                KinectSensor _kinect = KinectSensor.KinectSensors[0];

                //启用深度摄像头默认选项，注册事件，启动Kinect传感器
                _kinect.SkeletonStream.Enable();//启用骨骼追踪摄像机
                _kinect.DepthStream.Enable();
                //_kinect.DepthFrameReady += new EventHandler<DepthImageFrameReadyEventArgs>(_kinect_DepthFrameReady);
                _kinect.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(_kinect_SkeletonFrameReady);
                _kinect.Start();

                //按回车键退出
                while (Console.ReadKey().Key != ConsoleKey.Enter)
                {
                }

                //关闭Kinect传感器
                _kinect.Stop();
                Console.WriteLine("Exit the Kinect Matrix...");
            }
            else
            {
                Console.WriteLine("Please check the kinect sensor");
            }
        }



        //static void _kinect_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        //{
        //    //获取Kinect摄像头深度数据，并将深度值打印到控制台上
        //    using (DepthImageFrame depthFrame = e.OpenDepthImageFrame())
        //    {
        //        if (depthFrame != null)
        //        {
        //            short[] depthPixelData = new short[depthFrame.PixelDataLength];
        //            depthFrame.CopyPixelDataTo(depthPixelData);

        //            foreach (short pixel in depthPixelData)
        //            {
        //                Console.Write(pixel);

        //            }
        //        }
        //    }
        //}
        static void _kinect_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            bool isSkeletionDataReady = false;
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    skeletons = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    skeletonFrame.CopySkeletonDataTo(skeletons);
                    isSkeletionDataReady = true;

                }
            }
            if (isSkeletionDataReady)
            {
                Skeleton curretskeleton = (
                    from s in skeletons
                    where
                    s.TrackingState == SkeletonTrackingState.Tracked
                    select s).FirstOrDefault();
                if (curretskeleton != null)
                {
                    foreach (Joint item in curretskeleton.Joints)
                    {
                        writebone(item.JointType + " " + item.Position.X + " " + item.Position.Y + " " + item.Position.Z);
                        Console.WriteLine(item.JointType + " " + item.Position.X + " " + item.Position.Y + " " + item.Position.Z);
                    }
                    Joint head = curretskeleton.Joints[JointType.Head];
                    // Console.WriteLine(head.Position);
                    // writebone(head.Position.X+" "+head.Position.Y+" "+head.Position.Z);
                }
            }
        }
        static void writebone(string str)
        {
            if (!File.Exists("C:\\Users\\Administrator\\Desktop\\data.txt"))
            {
                FileInfo myfile = new FileInfo("C:\\Users\\Administrator\\Desktop\\data.txt");
                FileStream fs = myfile.Create();
                fs.Close();
            }
            StreamWriter sw = File.AppendText("C:\\Users\\Administrator\\Desktop\\data.txt");

            sw.WriteLine(str);
            sw.Flush();
            sw.Close();

        }

    }
}
