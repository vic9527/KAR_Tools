function Return = Sigmoid(Vector)
Return = 1./(1+exp(-Vector));
end