function Return = Tanh(Vector)
Return = (exp(2.*Vector)-1)./(exp(2.*Vector)+1);
end