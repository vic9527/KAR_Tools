function Return = Diff_Tanh(Vector)
Return = 1-Tanh(Vector).*Tanh(Vector);
end