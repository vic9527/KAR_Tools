# ActionLab
This repostory is used to record the codes that I use to do my action recognition labs. 
Now with four datasets, including MSR Action dateset, UTKinect action dataset, FLOA and MHAD.
