function out = fast_str2num(in)
  
[r,c] = size(in);
out = zeros(r,1);

for a=1:r
  
  out(a) = eval(in(a,:));
  
end
