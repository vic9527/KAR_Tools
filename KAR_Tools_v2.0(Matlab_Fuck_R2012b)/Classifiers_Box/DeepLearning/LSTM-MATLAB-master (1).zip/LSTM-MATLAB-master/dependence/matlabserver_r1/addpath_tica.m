%addpath /usr/local/jacket/engine/
%addpath ~/test/GPUmat/
addpath tica
addpath ../nis_code/
addpath ../localrf
%addpath ../localrf/tica/
addpath ../complexcell2.0/codebase/activationfunctions/
addpath ../complexcell2.0/codebase/costfunctions/


%addpath ../complexcell2.0/codebase/invariancetests/
%addpath ../complexcell2.0/codebase/network/
%addpath ../complexcell2.0/codebase/optimization/
%addpath ../localrf/projection/
%addpath ../localrf/test/
%addpath ../localrf/utility/
%addpath ../localrf/processing/
%addpath ../localrf/whitening/
%addpath ../localrf/visualization/
%addpath ../localrf/unittests/
%addpath ../localrf/softmax
%addpath ../localrf/dataloader
%addpath ../localrf/norb
%addpath ../localrf/audio
%addpath ../localrf/caltech

