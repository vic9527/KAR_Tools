addpath(genpath('./dependence'))
addpath data/  
 
slaveRun('localhost', 10000);

