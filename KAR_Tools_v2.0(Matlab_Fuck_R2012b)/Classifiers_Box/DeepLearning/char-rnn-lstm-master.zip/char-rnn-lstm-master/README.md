%matlab-min-char-rnn

%matlab version of the min-char-rnn

%Minimal character-level Vanilla RNN model. Written by Andrej Karpathy (@karpathy)
BSD License

%changed by YangXS for Matlab

%2015-08-23
