# LSTM

LSTM implementation in GNU Octave (Matlab compatible)

Source algorithm comes from Alex Grave's Book "Supervised Sequence Labelling with Recurrent Neural Networks"
