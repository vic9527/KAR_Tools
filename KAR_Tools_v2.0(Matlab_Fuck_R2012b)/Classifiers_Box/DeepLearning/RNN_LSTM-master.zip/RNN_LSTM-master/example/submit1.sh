qsub -pe smp 8 -q devel.q v1.sh
