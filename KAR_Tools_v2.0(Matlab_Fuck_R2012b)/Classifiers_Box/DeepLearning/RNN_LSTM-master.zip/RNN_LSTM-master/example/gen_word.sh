qsub -pe smp 8 -q devel.q v2.sh
